# Da Soundboard
This is an usual Soundboard made in Java

It uses the jnativehook library to detect globol key events
https://github.com/kwhat/jnativehook

It uses the jlayer library to handle mp3 files
http://www.javazoom.net/javalayer/javalayer.html